﻿namespace Lab91;

public class MoneyArray
{
    private Money[] items;
    private static int count;
    public int Length { get { return items.Length; } }
    public static int Count { get { return count; } }
    public MoneyArray() { items = new Money[0]; count++; }
    public MoneyArray(int length, Random random)
    {
        if (length < 0 || random == null) throw new ArgumentException("Некорректные параметры массива.");
        items = new Money[length];
        for (int i = 0; i < length; i++) items[i] = new Money(random.Next(0, 1000), random.Next(0, 100));
        count++;
    }
    public MoneyArray(Money[] values)
    {
        if (values == null) throw new ArgumentException("Массив не задан.");
        items = new Money[values.Length];
        for (int i = 0; i < values.Length; i++)
        {
            if (values[i] == null) throw new ArgumentException("Элемент не задан.");
            items[i] = values[i];
        }
        count++;
    }
    public Money this[int index]
    {
        get { if (index < 0 || index >= Length) throw new ArgumentException("Индекс вне границ массива."); return items[index]; }
        set { if (index < 0 || index >= Length || value == null) throw new ArgumentException("Некорректный индекс или элемент."); items[index] = value; }
    }
    public string GetElements()
    {
        if (Length == 0) return "Массив пуст.";
        string result = "";
        for (int i = 0; i < Length; i++) result += $"{i + 1}: {items[i]}\n";
        return result;
    }
}
