﻿namespace Lab91;

public class Money
{
    private int rubles;
    private int kopeks;
    private static int count;

    public int Rubles
    {
        get { return rubles; }
        set { if (value < 0) throw new ArgumentException("Рубли не могут быть отрицательными."); rubles = value; }
    }
    public int Kopeks
    {
        get { return kopeks; }
        set { if (value < 0 || value > 99) throw new ArgumentException("Копейки должны быть от 0 до 99."); kopeks = value; }
    }
    public static int Count { get { return count; } }
    public Money() : this(0, 0) { }
    public Money(int rubles, int kopeks) { Rubles = rubles; Kopeks = kopeks; count++; }
    private long TotalKopeks() { return (long)Rubles * 100 + Kopeks; }
    private static Money FromKopeks(long value)
    {
        if (value < 0 || value > (long)int.MaxValue * 100 + 99) throw new ArgumentException("Результат вне допустимого диапазона.");
        return new Money((int)(value / 100), (int)(value % 100));
    }
    public static bool Compare(Money first, Money second) { return first.TotalKopeks() == second.TotalKopeks(); }
    public bool Compare(Money other) { return Compare(this, other); }
    public static Money operator ++(Money value) { return FromKopeks(value.TotalKopeks() + 1); }
    public static Money operator --(Money value) { return FromKopeks(value.TotalKopeks() - 1); }
    public static implicit operator int(Money value) { return value.Rubles; }
    public static explicit operator double(Money value) { return value.Kopeks / 100.0; }
    public static Money operator -(Money value, int amount)
    {
        if (amount < 0) throw new ArgumentException("Количество копеек не может быть отрицательным.");
        return FromKopeks(value.TotalKopeks() - amount);
    }
    public static Money operator -(int amount, Money value)
    {
        if (amount < 0) throw new ArgumentException("Количество копеек не может быть отрицательным.");
        return FromKopeks((long)amount - value.TotalKopeks());
    }
    public override string ToString() { return $"{Rubles} руб. {Kopeks:D2} коп."; }
}
