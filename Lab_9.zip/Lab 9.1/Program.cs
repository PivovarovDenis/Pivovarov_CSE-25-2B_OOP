﻿namespace Lab91;

public class Program
{
    public static void Main(string[] args)
    {
        if (args.Length > 0 && args[0] == "--test") { Tests.Run(); return; }
        UserInterface.Run();
    }
    public static int FindMinimumIndex(MoneyArray array)
    {
        if (array == null || array.Length == 0) throw new ArgumentException("Массив пуст.");
        int min = 0;
        for (int i = 1; i < array.Length; i++)
            if (array[i].Rubles < array[min].Rubles || (array[i].Rubles == array[min].Rubles && array[i].Kopeks < array[min].Kopeks)) min = i;
        return min;
    }
}
