﻿namespace Lab91;

public static class UserInterface
{
    private static int ReadInt(string prompt, int min, int max)
    {
        while (true)
        {
            Console.Write(prompt);
            string? line = Console.ReadLine();
            if (line == null) throw new EndOfStreamException();
            if (int.TryParse(line, out int number) && number >= min && number <= max) return number;
            Console.WriteLine($"Введите целое число от {min} до {max}.");
        }
    }
    private static Money ReadMoney()
    {
        int rubles = ReadInt("Рубли: ", 0, int.MaxValue);
        int kopeks = ReadInt("Копейки (0–99): ", 0, 99);
        return new Money(rubles, kopeks);
    }
    public static void Run()
    {
        try
        {
            while (true)
            {
                Console.WriteLine("\nПрактическая работа 9, вариант 15\n1. Сравнение и операции\n2. Массив денежных сумм\n0. Выход");
                int choice = ReadInt("Выбор: ", 0, 2);
                if (choice == 0) return;
                if (choice == 1) Operations(); else ArrayMenu();
            }
        }
        catch (EndOfStreamException) { Console.WriteLine("Ввод завершён."); }
    }
    private static void Operations()
    {
        Console.WriteLine("Первая сумма:"); Money first = ReadMoney();
        Console.WriteLine("Вторая сумма:"); Money second = ReadMoney();
        Console.WriteLine($"Равны (статический метод): {Money.Compare(first, second)}");
        Console.WriteLine($"Равны (метод объекта): {first.Compare(second)}");
        try { Money increased = first; increased++; Console.WriteLine($"После ++: {increased}"); } catch (ArgumentException ex) { Console.WriteLine(ex.Message); }
        try { Money decreased = first; decreased--; Console.WriteLine($"После --: {decreased}"); } catch (ArgumentException ex) { Console.WriteLine(ex.Message); }
        int rubles = first; double fractional = (double)first;
        Console.WriteLine($"Рубли (int): {rubles}; копейки в рублях (double): {fractional:F2}");
        int amount = ReadInt("Количество копеек для вычитания: ", 0, int.MaxValue);
        try { Console.WriteLine($"Сумма - копейки: {first - amount}"); } catch (ArgumentException ex) { Console.WriteLine(ex.Message); }
        try { Console.WriteLine($"Копейки - сумма: {amount - first}"); } catch (ArgumentException ex) { Console.WriteLine(ex.Message); }
        Counts();
    }
    private static void ArrayMenu()
    {
        int choice = ReadInt("1 — пустой, 2 — случайный, 3 — ввод: ", 1, 3);
        MoneyArray array;
        if (choice == 1) array = new MoneyArray();
        else
        {
            int length = ReadInt("Размер массива (0–100): ", 0, 100);
            if (choice == 2) array = new MoneyArray(length, new Random());
            else
            {
                Money[] items = new Money[length];
                for (int i = 0; i < length; i++) { Console.WriteLine($"Элемент {i + 1}:"); items[i] = ReadMoney(); }
                array = new MoneyArray(items);
            }
        }
        Console.WriteLine(array.GetElements());
        if (array.Length > 0) { int index = Program.FindMinimumIndex(array); Console.WriteLine($"Номер минимального элемента: {index + 1}; сумма: {array[index]}"); }
        Counts();
    }
    private static void Counts() { Console.WriteLine($"Создано Money: {Money.Count}; MoneyArray: {MoneyArray.Count}"); }
}
