﻿namespace Lab91;

public static class Tests
{
    private static int passed;
    private static int total;
    private static void Check(string name, bool condition)
    {
        total++; if (condition) passed++;
        Console.WriteLine($"{name}: {(condition ? "PASS" : "FAIL")}");
    }
    private static bool Throws(Action action)
    {
        try { action(); return false; } catch (ArgumentException) { return true; }
    }
    public static void Run()
    {
        Money a = new Money(2, 50); Money same = new Money(2, 50); Money b = new Money(1, 99);
        Check("T01 сравнение равных статически", Money.Compare(a, same));
        Check("T02 сравнение разных статически", !Money.Compare(a, b));
        Check("T03 сравнение равных методом", a.Compare(same));
        Check("T04 сравнение разных методом", !a.Compare(b));
        Money inc = new Money(1, 99); inc++; Check("T05 ++ переход через рубль", inc.Rubles == 2 && inc.Kopeks == 0);
        Money dec = new Money(2, 0); dec--; Check("T06 -- переход через рубль", dec.Rubles == 1 && dec.Kopeks == 99);
        Check("T07 -- ноль", Throws(() => { Money zero = new Money(); zero--; }));
        int whole = a; Check("T08 неявный int", whole == 2);
        double fraction = (double)a; Check("T09 явный double", fraction == 0.5);
        Money left = a - 51; Check("T10 сумма - копейки", left.Rubles == 1 && left.Kopeks == 99);
        Money right = 300 - a; Check("T11 копейки - сумма", right.Rubles == 0 && right.Kopeks == 50);
        Check("T12 отрицательный результат слева", Throws(() => { Money x = a - 251; }));
        Check("T13 отрицательный результат справа", Throws(() => { Money x = 249 - a; }));
        Check("T14 отрицательное число копеек", Throws(() => { Money x = a - (-1); }));
        Check("T15 неверные рубли", Throws(() => { Money x = new Money(-1, 0); }));
        Check("T16 неверные копейки", Throws(() => { Money x = new Money(0, 100); }));
        MoneyArray empty = new MoneyArray(); Check("T17 пустой массив", empty.Length == 0);
        Check("T18 минимум пустого массива", Throws(() => Program.FindMinimumIndex(empty)));
        MoneyArray array = new MoneyArray(new Money[] { new Money(3, 10), new Money(1, 5), new Money(1, 5), new Money(2, 0) });
        Check("T19 первый из равных минимумов", Program.FindMinimumIndex(array) == 1);
        Check("T20 индексатор чтение", array[1].Kopeks == 5);
        Check("T21 индекс за границей", Throws(() => { Money x = array[4]; }));
        array[0] = new Money(0, 1); Check("T22 индексатор запись и минимум", Program.FindMinimumIndex(array) == 0);
        MoneyArray random = new MoneyArray(2, new Random(7)); Check("T23 случайный массив", random.Length == 2 && random[0].Kopeks < 100);
        Check("T24 отрицательная длина", Throws(() => { MoneyArray x = new MoneyArray(-1, new Random()); }));
        Check("T25 переполнение ++", Throws(() => { Money x = new Money(int.MaxValue, 99); x++; }));
        Console.WriteLine($"ИТОГ: {passed}/{total}");
        if (passed != total) Environment.ExitCode = 1;
    }
}
